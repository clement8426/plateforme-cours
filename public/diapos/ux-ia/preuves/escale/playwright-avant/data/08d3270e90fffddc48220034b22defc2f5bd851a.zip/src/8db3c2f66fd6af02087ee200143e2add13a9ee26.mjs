export const base=process.env.ESC_URL||'http://127.0.0.1:4201';
export async function ready(page){await page.waitForFunction(()=>localStorage.getItem('escale-demo-v1')!==null);await page.evaluate(()=>document.fonts.ready);}
export async function seed(page,mode='avant'){await page.goto(`${base}/?mode=${mode}`);await ready(page);await page.evaluate(()=>{const k='escale-demo-v1';const v=JSON.parse(localStorage.getItem(k));v.cart=[{id:'sac-weekend',qty:1}];v.profile=null;localStorage.setItem(k,JSON.stringify(v));sessionStorage.removeItem('escale-order')});}
export async function fillForm(page){for(const [id,value] of Object.entries({name:'Camille Démo',email:'camille@example.test',address:'Rue de la Démo 12',postal:'20',city:'Neuchâtel',phone:'079 123 45 67'}))await page.locator(`#${id}`).fill(value);}
export async function setOnly(page,ids){await page.evaluate(ids=>{const k='escale-demo-v1';const v=JSON.parse(localStorage.getItem(k)||'{}');localStorage.setItem(k,JSON.stringify({...v,fixes:ids}));},ids);}
export const escapeHtml=value=>String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
