import {test,expect} from 'playwright/test';
import {seed,fillForm} from '../scripts/test-utils.mjs';
for(const mode of ['avant','apres'])test(`conservation des saisies · ${mode}`,async({page})=>{
 test.skip(process.env.ESC_SCENARIO&&process.env.ESC_SCENARIO!==mode,'Autre scénario');
 await test.step('Préparer un panier et la commande',async()=>{await seed(page,mode);await page.goto(`/commande?mode=${mode}`)});
 await test.step('Remplir les coordonnées et un code postal invalide',()=>fillForm(page));
 await test.step('Soumettre et vérifier que Camille est conservé',async()=>{await page.getByRole('button',{name:/Confirmer la commande fictive/}).click();await expect(page.locator('#name')).toHaveValue('Camille Démo')});
});
