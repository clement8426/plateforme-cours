# Atelier Rayon : le formulaire d'adresse

Boutique fictive, créée pour un exercice d'UX. Le formulaire n'envoie aucune donnée.

## Ouvrir le formulaire

Double-cliquez sur `index.html` : il s'ouvre dans votre navigateur. Rien à installer.

## L'exercice

1. **Remplissez le formulaire**, chrono lancé, avec une adresse **fictive** en Suisse. Ne mettez pas vos vraies coordonnées.
2. **Notez tout ce qui vous gêne**, même un détail : ce qui ralentit, ce qui fait douter, ce qui énerve.
3. **Corrigez avec l'IA** : donnez le dossier à votre assistant (Claude, ChatGPT, Codex…) et demandez-lui de corriger ce que vous avez repéré, défaut par défaut.
4. **Dernière étape, l'autocomplétion.** Demandez par exemple :

> Ajoute l'autocomplétion d'adresse sur le champ « Rue et numéro » avec l'API Photon (https://photon.komoot.io/api/), gratuite et sans clé. Limite les résultats à la Suisse, attends 300 ms après la dernière frappe et 3 caractères minimum avant de chercher, propose 5 adresses au plus, remplis le NPA et la localité au clic, rends la liste utilisable au clavier, garde la saisie manuelle possible si rien ne convient, et affiche l'attribution « © contributeurs OpenStreetMap ».

## Bon à savoir

- Le serveur public de Photon est gratuit pour un **usage raisonnable** : pas de recherche à chaque frappe sans délai.
- L'autocomplétion envoie ce que vous tapez à un service tiers : d'où l'adresse fictive.
